class TelegramMessage {
    Long chat_id
    String text
}