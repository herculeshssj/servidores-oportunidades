package br.com.hslife.oportunidade.model

class TelegramMessage {
    Long chat_id
    String text
}