package br.com.hslife.oportunidade.util

class Util {

    static List<String> estados() {
        List<String> lista = new ArrayList<>()
        lista.add("Todos")
        lista.add("Nacional")
        lista.add("AC")
        lista.add("AL")
        lista.add("AM")
        lista.add("AP")
        lista.add("BA")
        lista.add("CE")
        lista.add("DF")
        lista.add("ES")
        lista.add("GO")
        lista.add("MA")
        lista.add("MG")
        lista.add("MS")
        lista.add("MT")
        lista.add("PA")
        lista.add("PB")
        lista.add("PE")
        lista.add("PI")
        lista.add("PR")
        lista.add("RJ")
        lista.add("RN")
        lista.add("RO")
        lista.add("RR")
        lista.add("RS")
        lista.add("SC")
        lista.add("SE")
        lista.add("SP")
        lista.add("TO")
        return lista
    }
}
