package br.com.hslife.oportunidade

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ServidoresOportunidadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
